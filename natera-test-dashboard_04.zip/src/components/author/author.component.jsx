import React from 'react';

const Author = () => {
  return <div className="author"></div>;
};

export default Author;
