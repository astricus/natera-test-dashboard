import React from 'react';

import './button-inline.styles.scss';

const ButtonInline = (props) => {
  return (
    <button className={`btn-inline ${props.className}`}>
      {props.children}
    </button>
  );
};

export default ButtonInline;
