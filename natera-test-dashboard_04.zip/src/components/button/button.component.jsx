import React from 'react';

import './button.styles.scss';

const Button = (props) => {
  return (
    <button
      type="button"
      className={`btn ${props.primary ? 'btn--primary' : ''} ${
        props.secondary ? 'btn--secondary' : ''
      } ${props.danger ? 'btn--danger' : ''} ${props.className}`}
      onClick={props.onClick}
    >
      {props.children}
    </button>
  );
};

export default Button;
