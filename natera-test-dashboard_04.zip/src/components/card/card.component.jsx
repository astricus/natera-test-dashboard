import React from 'react';

import './card.styles.scss';

const Card = (props) => (
  <div className={`card ${props.isPost ? 'card--post' : ''}`}>
    {props.children}
  </div>
);

export default Card;
