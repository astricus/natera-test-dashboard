import React from 'react';
import { connect } from 'react-redux';
import CompanyInfo from '../company-info/company-info.component';
import Highlights from '../highlights/highlights.component';
import Notification from '../notifications/notification.component';
import ProjectsStatuses from '../projects-statuses/projects-statuses.component';
import Footer from '../footer/footer.component';

import './dashboard-mode.styles.scss';

const DashboardMode = ({ mode }) => {
  return (
    <div className={`dashboard-mode ${!mode ? 'd-non' : ''}`}>
      <CompanyInfo />
      <Highlights />
      <Notification />
      <ProjectsStatuses key={`projects-statuses__${mode}`} />
      <Footer />
    </div>
  );
};

const mapStateToProps = ({ mode: { mode } }) => ({
  mode: mode,
});

export default connect(mapStateToProps)(DashboardMode);
