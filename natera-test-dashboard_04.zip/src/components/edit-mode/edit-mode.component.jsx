import React from 'react';
import { connect } from 'react-redux';
import Highlights from '../highlights/highlights.component';
import NotificationsSwitch from '../notifications-switch/notifications-switch.component';
import ProjectsStatuses from '../projects-statuses/projects-statuses.component';
import Footer from '../footer/footer.component';

import './edit-mode.styles.scss';

const EditMode = ({ mode }) => {
  return (
    <div className={`edit-mode ${mode ? 'd-non' : ''} d-non-xs`}>
      <Highlights />
      <ProjectsStatuses key={`projects-statuses__${mode}`} />
      <NotificationsSwitch />
      <Footer />
    </div>
  );
};

const mapStateToProps = ({ mode: { mode } }) => ({
  mode: mode,
});

export default connect(mapStateToProps)(EditMode);
