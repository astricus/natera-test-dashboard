import React from 'react';

import './column.styles.scss';

const Column = (props) => {
  return <div className={props.col}>{props.children}</div>;
};

export default Column;
