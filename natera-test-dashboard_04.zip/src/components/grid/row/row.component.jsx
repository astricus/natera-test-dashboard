import React from 'react';

import './row.styles.scss';

const Row = (props) => {
  return <div className="row">{props.children}</div>;
};

export default Row;
