import React from 'react';
import { connect } from 'react-redux';
import { setMode } from '../../redux/mode/mode.actions';
import Container from '../grid/container/container.component';

import './header.styles.scss';

const Header = ({ mode, setMode }) => {
  const setAppMode = (mode) => {
    setMode(mode);
  };
  return (
    <div className="header">
      <Container>
        <ul className="header__navigation navigation">
          <li>
            <button
              className={`navigation__item ${
                mode ? 'navigation__item--active' : ''
              }`}
              onClick={() => setAppMode(true)}
            >
              Dashboard mode
            </button>
          </li>
          <li>
            <button
              className={`navigation__item ${
                !mode ? 'navigation__item--active' : ''
              } d-non-xs`}
              onClick={() => setAppMode(false)}
            >
              Edit mode
            </button>
          </li>
        </ul>
      </Container>
    </div>
  );
};

const mapStateToProps = ({ mode: { mode } }) => ({
  mode: mode,
});

const mapDispatchToProps = (dispatch) => ({
  setMode: (mode) => dispatch(setMode(mode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Header);
