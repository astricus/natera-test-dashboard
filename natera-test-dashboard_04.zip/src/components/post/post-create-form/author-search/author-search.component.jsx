import React, { useState } from 'react';
import { connect } from 'react-redux';
import Autosuggest from 'react-autosuggest';

import './author-search.styles.scss';

const AuthorSearch = ({ users, value, onChange }) => {
  const [suggestions, setSuggestions] = useState([]);

  const getSuggestions = (value) => {
    const inputValue = value.trim().toLowerCase();
    const inputLength = inputValue.length;

    return users.filter(
      (user) => user.name.toLowerCase().slice(0, inputLength) === inputValue
    );
  };

  const getSuggestionValue = (suggestion) => suggestion.name;

  const shouldRenderSuggestions = () => {
    return true;
  };

  const renderSuggestion = (suggestion) => (
    <div className="react-autosuggest__suggestion-wrapper">
      <img
        src={suggestion.avatarUrl}
        alt="Author"
        className="react-autosuggest__suggestion-avatar"
      />
      {suggestion.name}
    </div>
  );

  const onSuggestionsFetchRequested = ({ value }) =>
    setSuggestions(getSuggestions(value));

  const onSuggestionsClearRequested = () => setSuggestions([]);
  const inputProps = {
    placeholder: 'Who said?',
    value,
    onChange: onChange,
  };

  return (
    <Autosuggest
      suggestions={suggestions}
      onSuggestionsFetchRequested={onSuggestionsFetchRequested}
      onSuggestionsClearRequested={onSuggestionsClearRequested}
      getSuggestionValue={getSuggestionValue}
      shouldRenderSuggestions={shouldRenderSuggestions}
      renderSuggestion={renderSuggestion}
      inputProps={inputProps}
    />
  );
};

const mapStateToProps = ({ users: { users } }) => ({
  users: users,
});

export default connect(mapStateToProps)(AuthorSearch);
