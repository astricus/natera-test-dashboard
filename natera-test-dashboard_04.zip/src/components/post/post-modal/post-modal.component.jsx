import React from 'react';
import { connect } from 'react-redux';
import { hideModal } from '../../../redux/posts/posts.actions';
import Modal from '../../modal/modal.component';
import PostTitleStatistical from '../post-title-statistical/post-title-statistical.component';
import PostAuthor from '../post-author/post-author.component';
import Button from '../../button/button.component';

import './post-modal.styles.scss';

const PostModal = ({ postId, isVisible, posts, hideModal }) => {
  if (posts.find((post) => post.id === postId)) {
    const { type, title, text, imageUrl, authorId } = posts.find(
      (post) => post.id === postId
    );

    const postModalClose = () => hideModal();

    return (
      <Modal isVisible={isVisible}>
        <div className="post-modal">
          {imageUrl ? (
            <img src={imageUrl} alt="Post" className="post-modal__image" />
          ) : null}
          <div className="post-modal__post">
            {type === 'ordinary' ? (
              <h3 className="post-modal__title">{title}</h3>
            ) : (
              <PostTitleStatistical
                title={title}
                className="post-modal__title-statistical"
              />
            )}
            <p className="post-modal__text">{text}</p>
            <PostAuthor
              mode={true}
              authorId={authorId}
              className="post-modal__author"
            />
          </div>
          <div className="post-modal__btn-wrapper">
            <Button
              primary={true}
              className="btn--primary--close"
              onClick={postModalClose}
            >
              Close
            </Button>
          </div>
        </div>
      </Modal>
    );
  } else return null;
};

const mapDispatchToProps = (dispatch) => ({
  hideModal: () => dispatch(hideModal()),
});

const mapStateToProps = ({ posts }) => ({
  posts: posts.posts,
  isVisible: posts.modalIsVisible,
  postId: posts.currentPostId,
});

export default connect(mapStateToProps, mapDispatchToProps)(PostModal);
