import React from 'react';
import Section from '../section/section.component';
import SecondaryHeading from '../typography/secondary-heading/secondary-heading.component';
import Row from '../grid/row/row.component';
import Column from '../grid/column/column.component';
import Card from '../card/card.component';
import ProjectStatusesTable from './projects-statuses-table/projects-statuses-table.component';

// import './projects-statuses.styles.scss';

const ProjectsStatuses = () => (
  <Section>
    <SecondaryHeading>Projects Statuses</SecondaryHeading>
    <Row>
      <Column col="col-12">
        <Card>
          <ProjectStatusesTable />
        </Card>
      </Column>
    </Row>
  </Section>
);

export default ProjectsStatuses;
