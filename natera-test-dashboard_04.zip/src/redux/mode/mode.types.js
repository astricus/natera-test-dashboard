export const ModeActionTypes = {
  SET_MODE: 'SET_MODE',
};
