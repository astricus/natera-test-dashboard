export const ProjectsActionTypes = {
  DELETE_PROJECT: 'DELETE_PROJECT',
};
