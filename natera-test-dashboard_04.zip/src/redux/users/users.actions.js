import { UsersActionTypes } from './users.types';

export const createNewUser = ({ userName, userId }) => ({
  type: UsersActionTypes.CREATE_NEW_USER,
  payload: { userName, userId },
});
