export const UsersActionTypes = {
  CREATE_NEW_USER: 'CREATE_NEW_USER',
};
